from .__main__ import add, sub, mul, div
